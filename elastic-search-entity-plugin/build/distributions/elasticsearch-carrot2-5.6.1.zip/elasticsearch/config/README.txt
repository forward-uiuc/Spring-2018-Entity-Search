Place any algorithm-specific lexical resource overrides here.

Lingo3G:
http://download.carrotsearch.com/lingo3g/manual/#chapter.lexical-resources

Lingo, STC, kMeans:
http://download.carrot2.org/head/manual/#chapter.lexical-resources